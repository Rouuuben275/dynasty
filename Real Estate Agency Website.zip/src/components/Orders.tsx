import { useState, useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { Package, User, Phone, Calendar, CheckCircle2, Clock, XCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { projectId } from '../utils/supabase/info';

interface Order {
  id: string;
  userId: string;
  username: string;
  items: any[];
  rpName: string;
  phoneNumber: string;
  notes: string;
  status: string;
  createdAt: number;
}

interface OrdersProps {
  sessionToken: string | null;
}

export function Orders({ sessionToken }: OrdersProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-efc46249`;

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const response = await fetch(`${API_BASE}/orders`, {
        headers: {
          'Authorization': `Bearer ${sessionToken}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setOrders(data.orders || []);
      } else {
        const error = await response.json();
        toast.error(error.error || 'Erreur lors du chargement des commandes');
      }
    } catch (error) {
      console.error('Failed to fetch orders:', error);
      toast.error('Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (orderId: string, newStatus: string) => {
    try {
      const response = await fetch(`${API_BASE}/orders/${orderId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionToken}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (response.ok) {
        toast.success('Statut mis à jour');
        fetchOrders();
      } else {
        const error = await response.json();
        toast.error(error.error || 'Erreur lors de la mise à jour');
      }
    } catch (error) {
      console.error('Update status error:', error);
      toast.error('Erreur de connexion');
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const formatDate = (timestamp: number) => {
    return new Intl.DateTimeFormat('fr-FR', {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(new Date(timestamp));
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-600 text-white border-0"><Clock className="w-3 h-3 mr-1" />En attente</Badge>;
      case 'completed':
        return <Badge className="bg-green-600 text-white border-0"><CheckCircle2 className="w-3 h-3 mr-1" />Complété</Badge>;
      case 'cancelled':
        return <Badge className="bg-red-600 text-white border-0"><XCircle className="w-3 h-3 mr-1" />Annulé</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-white text-xl">Chargement des commandes...</div>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-20">
        <Package className="w-24 h-24 text-emerald-500 mx-auto mb-4 opacity-50" />
        <h2 className="text-2xl font-bold text-white mb-2">Aucune commande</h2>
        <p className="text-gray-400">Les commandes apparaîtront ici</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Gestion des commandes ({orders.length})</h2>
      </div>

      <div className="space-y-4">
        {orders.map((order) => (
          <Card key={order.id} className="bg-[#1a1a1a] border-gray-800">
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-lg font-bold text-white">Commande #{order.id.slice(0, 8)}</h3>
                    {getStatusBadge(order.status)}
                  </div>
                  <div className="flex items-center gap-2 text-gray-400 text-sm">
                    <Calendar className="w-4 h-4" />
                    {formatDate(order.createdAt)}
                  </div>
                </div>

                <Select
                  value={order.status}
                  onValueChange={(value) => handleUpdateStatus(order.id, value)}
                >
                  <SelectTrigger className="w-40 bg-black/50 border-gray-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">En attente</SelectItem>
                    <SelectItem value="completed">Complété</SelectItem>
                    <SelectItem value="cancelled">Annulé</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Customer Info */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-black/30 border border-gray-800 rounded-lg p-4">
                <div>
                  <div className="flex items-center gap-2 text-gray-400 mb-1">
                    <User className="w-4 h-4" />
                    <p className="text-sm">Client Discord</p>
                  </div>
                  <p className="text-white font-medium">{order.username}</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 text-gray-400 mb-1">
                    <User className="w-4 h-4" />
                    <p className="text-sm">Nom RP</p>
                  </div>
                  <p className="text-white font-medium">{order.rpName}</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 text-gray-400 mb-1">
                    <Phone className="w-4 h-4" />
                    <p className="text-sm">Téléphone RP</p>
                  </div>
                  <p className="text-white font-medium">{order.phoneNumber}</p>
                </div>
              </div>

              {/* Properties */}
              <div>
                <h4 className="text-white font-semibold mb-3">Propriétés commandées</h4>
                <div className="space-y-2">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex items-center justify-between bg-black/30 border border-gray-800 rounded-lg p-3">
                      <div>
                        <p className="text-white font-medium">{item.name}</p>
                        <p className="text-gray-400 text-sm">{item.category} • {item.saleType === 'vente' ? 'Vente' : 'Location'}</p>
                      </div>
                      <p className="text-white font-bold">{formatPrice(item.price)}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Notes */}
              {order.notes && (
                <div>
                  <h4 className="text-white font-semibold mb-2">Notes / Demandes spéciales</h4>
                  <p className="text-gray-400 bg-black/30 border border-gray-800 rounded-lg p-3">{order.notes}</p>
                </div>
              )}

              {/* Total */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-800">
                <p className="text-gray-400 font-semibold">Total</p>
                <p className="text-2xl font-bold text-white">
                  {formatPrice(order.items.reduce((sum, item) => sum + item.price, 0))}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}