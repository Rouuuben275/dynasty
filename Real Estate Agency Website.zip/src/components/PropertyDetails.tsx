import { useState, useEffect } from 'react';
import { ArrowLeft, MapPin, DollarSign, Home, Bed, Bath, Maximize, Car, Package } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { projectId } from '../utils/supabase/info';

interface Property {
  id: string;
  name: string;
  price: number;
  category: string;
  saleType: 'vente' | 'location';
  description: string;
  photos: string[];
  location?: string;
  bedrooms?: number;
  bathrooms?: number;
  surface?: number;
  garageSpaces?: number;
  storage?: number;
  features?: string[];
}

interface PropertyDetailsProps {
  propertyId: string;
  sessionToken: string | null;
  onBack: () => void;
  onAddToCart: (property: Property) => void;
}

export function PropertyDetails({ propertyId, sessionToken, onBack, onAddToCart }: PropertyDetailsProps) {
  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);

  const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-efc46249`;

  useEffect(() => {
    fetchProperty();
  }, [propertyId]);

  const fetchProperty = async () => {
    try {
      const response = await fetch(`${API_BASE}/properties/${propertyId}`);
      const data = await response.json();
      setProperty(data.property);
    } catch (error) {
      console.error('Failed to fetch property:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-white text-xl">Chargement...</div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="text-center py-20">
        <p className="text-white/60 text-lg">Propriété non trouvée</p>
        <Button onClick={onBack} className="mt-4">Retour au catalogue</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back Button */}
      <Button
        variant="outline"
        onClick={onBack}
        className="border-gray-700 text-gray-300 hover:bg-white/5"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Retour au catalogue
      </Button>

      {/* Photos Gallery */}
      <div className="relative h-96 rounded-2xl overflow-hidden bg-black">
        {property.photos && property.photos.length > 0 ? (
          <>
            <ImageWithFallback
              src={property.photos[currentPhotoIndex]}
              alt={`${property.name} - Photo ${currentPhotoIndex + 1}`}
              className="w-full h-full object-cover"
            />
            
            {property.photos.length > 1 && (
              <>
                <button
                  onClick={() => setCurrentPhotoIndex((prev) => (prev - 1 + property.photos.length) % property.photos.length)}
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/70 text-white p-3 rounded-full hover:bg-black/90 transition-colors"
                >
                  ←
                </button>
                <button
                  onClick={() => setCurrentPhotoIndex((prev) => (prev + 1) % property.photos.length)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/70 text-white p-3 rounded-full hover:bg-black/90 transition-colors"
                >
                  →
                </button>
                
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {property.photos.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentPhotoIndex(index)}
                      className={`w-2 h-2 rounded-full transition-colors ${
                        index === currentPhotoIndex ? 'bg-white' : 'bg-white/50'
                      }`}
                    />
                  ))}
                </div>
              </>
            )}
          </>
        ) : (
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800"
            alt={property.name}
            className="w-full h-full object-cover"
          />
        )}

        <Badge className="absolute top-4 right-4 bg-emerald-500 text-white border-0 text-lg px-4 py-2">
          {property.saleType === 'vente' ? 'À vendre' : 'À louer'}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Info */}
        <Card className="lg:col-span-2 bg-[#1a1a1a] border-gray-800">
          <CardHeader>
            <h1 className="text-3xl font-bold text-white mb-2">{property.name}</h1>
            <div className="flex items-center gap-2 text-gray-400">
              <MapPin className="w-5 h-5" />
              <p className="text-lg">{property.location || 'Los Santos'}</p>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="flex items-center gap-3">
              <DollarSign className="w-8 h-8 text-emerald-500" />
              <div>
                <p className="text-3xl font-bold text-white">{formatPrice(property.price)}</p>
                <p className="text-gray-400 text-sm">
                  {property.saleType === 'vente' ? 'Prix de vente' : 'Loyer mensuel'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-black/30 rounded-lg p-4 text-center border border-gray-800">
                <Home className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                <p className="text-white font-semibold">{property.category}</p>
                <p className="text-gray-400 text-sm">Type</p>
              </div>

              {property.bedrooms !== undefined && (
                <div className="bg-black/30 rounded-lg p-4 text-center border border-gray-800">
                  <Bed className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                  <p className="text-white font-semibold">{property.bedrooms}</p>
                  <p className="text-gray-400 text-sm">Chambres</p>
                </div>
              )}

              {property.bathrooms !== undefined && (
                <div className="bg-black/30 rounded-lg p-4 text-center border border-gray-800">
                  <Bath className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                  <p className="text-white font-semibold">{property.bathrooms}</p>
                  <p className="text-gray-400 text-sm">Salles de bain</p>
                </div>
              )}

              {property.surface !== undefined && (
                <div className="bg-black/30 rounded-lg p-4 text-center border border-gray-800">
                  <Maximize className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                  <p className="text-white font-semibold">{property.surface} m²</p>
                  <p className="text-gray-400 text-sm">Surface</p>
                </div>
              )}

              {property.garageSpaces !== undefined && (
                <div className="bg-black/30 rounded-lg p-4 text-center border border-gray-800">
                  <Car className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                  <p className="text-white font-semibold">{property.garageSpaces}</p>
                  <p className="text-gray-400 text-sm">Places garage</p>
                </div>
              )}

              {property.storage !== undefined && (
                <div className="bg-black/30 rounded-lg p-4 text-center border border-gray-800">
                  <Package className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                  <p className="text-white font-semibold">{property.storage} m³</p>
                  <p className="text-gray-400 text-sm">Stockage</p>
                </div>
              )}
            </div>

            <div>
              <h3 className="text-xl font-semibold text-white mb-3">Description</h3>
              <p className="text-gray-400 leading-relaxed whitespace-pre-wrap">{property.description}</p>
            </div>

            {property.features && property.features.length > 0 && (
              <div>
                <h3 className="text-xl font-semibold text-white mb-3">Caractéristiques</h3>
                <div className="grid grid-cols-2 gap-2">
                  {property.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 text-gray-400">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Sidebar - Contact */}
        <Card className="bg-[#1a1a1a] border-gray-800 h-fit sticky top-24">
          <CardHeader>
            <h3 className="text-xl font-bold text-white">Intéressé par cette propriété ?</h3>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-400 text-sm">
              Ajoutez cette propriété à votre panier et passez commande pour être contacté par nos agents Dynasty 8.
            </p>

            <Button
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-lg py-6"
              onClick={() => onAddToCart(property)}
            >
              Ajouter au panier
            </Button>

            <div className="pt-4 border-t border-gray-800">
              <h4 className="text-white font-semibold mb-2">Contact Dynasty 8</h4>
              <p className="text-gray-400 text-sm">
                Rejoignez notre serveur Discord pour plus d'informations et bénéficier d'un support personnalisé.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}