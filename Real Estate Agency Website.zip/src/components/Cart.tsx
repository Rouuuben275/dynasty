import { useState } from 'react';
import { toast } from 'sonner@2.0.3';
import { ShoppingCart, Trash2, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { projectId } from '../utils/supabase/info';

interface CartProps {
  cart: any[];
  sessionToken: string | null;
  user: any;
  onRemoveFromCart: (index: number) => void;
  onCheckout: () => void;
}

export function Cart({ cart, sessionToken, user, onRemoveFromCart, onCheckout }: CartProps) {
  const [rpName, setRpName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-efc46249`;

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!sessionToken) {
      toast.error('Veuillez vous connecter pour passer commande');
      return;
    }

    if (!user?.isInGuild) {
      toast.error('Vous devez rejoindre le serveur Discord Dynasty 8 pour passer commande');
      return;
    }

    if (cart.length === 0) {
      toast.error('Votre panier est vide');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`${API_BASE}/orders`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionToken}`,
        },
        body: JSON.stringify({
          items: cart,
          rpName,
          phoneNumber,
          notes,
        }),
      });

      if (response.ok) {
        toast.success('Commande passée avec succès ! Un vendeur vous contactera bientôt sur Discord.');
        setRpName('');
        setPhoneNumber('');
        setNotes('');
        onCheckout();
      } else {
        const error = await response.json();
        if (error.joinUrl) {
          toast.error(error.error);
        } else {
          toast.error(error.error || 'Erreur lors de la commande');
        }
      }
    } catch (error) {
      console.error('Order error:', error);
      toast.error('Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  const totalPrice = cart.reduce((sum, item) => sum + item.price, 0);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  if (cart.length === 0) {
    return (
      <div className="text-center py-20">
        <ShoppingCart className="w-24 h-24 text-emerald-500 mx-auto mb-4 opacity-50" />
        <h2 className="text-2xl font-bold text-white mb-2">Votre panier est vide</h2>
        <p className="text-gray-400">Parcourez notre catalogue pour ajouter des propriétés</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Cart Items */}
      <div className="lg:col-span-2 space-y-4">
        <h2 className="text-2xl font-bold text-white mb-4">Votre panier ({cart.length})</h2>
        
        {cart.map((item, index) => (
          <Card key={index} className="bg-[#1a1a1a] border-gray-800">
            <div className="p-4">
              <div className="flex gap-4">
                <div className="w-32 h-24 rounded-lg overflow-hidden flex-shrink-0">
                  <ImageWithFallback
                    src={item.photos?.[0] || 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800'}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="flex-1">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-bold text-white">{item.name}</h3>
                      <div className="flex gap-2 mt-1">
                        <Badge variant="outline" className="text-gray-400 border-gray-700">
                          {item.category}
                        </Badge>
                        <Badge className="bg-emerald-500 text-white border-0">
                          {item.saleType === 'vente' ? 'Vente' : 'Location'}
                        </Badge>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="text-xl font-bold text-white">{formatPrice(item.price)}</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onRemoveFromCart(index)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-500/20 mt-2"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Retirer
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Order Form */}
      <Card className="bg-[#1a1a1a] border-gray-800 h-fit sticky top-24">
        <CardHeader>
          <h3 className="text-xl font-bold text-white">Finaliser la commande</h3>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmitOrder} className="space-y-4">
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4 mb-4">
              <p className="text-gray-400 text-sm mb-2">Total</p>
              <p className="text-3xl font-bold text-white">{formatPrice(totalPrice)}</p>
            </div>

            {!user?.isInGuild && (
              <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-4 mb-4">
                <p className="text-red-300 text-sm">
                  ⚠️ Vous devez rejoindre le serveur Discord Dynasty 8 pour passer commande
                </p>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="rpName" className="text-white">Nom & Prénom RP *</Label>
              <Input
                id="rpName"
                value={rpName}
                onChange={(e) => setRpName(e.target.value)}
                className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500"
                placeholder="John Doe"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phoneNumber" className="text-white">Numéro de téléphone (en jeu) *</Label>
              <Input
                id="phoneNumber"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500"
                placeholder="555-0123"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="text-white">Notes / Demandes spéciales</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500 min-h-24"
                placeholder="Informations supplémentaires..."
              />
            </div>

            <Button
              type="submit"
              disabled={loading || !user?.isInGuild}
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-lg py-6"
            >
              <Send className="w-5 h-5 mr-2" />
              {loading ? 'Envoi en cours...' : 'Passer commande'}
            </Button>

            <p className="text-xs text-gray-400 text-center">
              En passant commande, un ticket Discord sera créé pour que nos vendeurs puissent vous contacter
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}