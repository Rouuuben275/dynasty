import { useState, useEffect } from 'react';
import { Search, Filter, MapPin, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardFooter, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { projectId } from '../utils/supabase/info';

interface Property {
  id: string;
  name: string;
  price: number;
  category: string;
  saleType: 'vente' | 'location';
  description: string;
  photos: string[];
  location?: string;
  bedrooms?: number;
  bathrooms?: number;
  surface?: number;
  garageSpaces?: number;
  storage?: number;
  createdAt: number;
}

interface CatalogProps {
  sessionToken: string | null;
  onViewProperty: (propertyId: string) => void;
  onAddToCart: (property: Property) => void;
}

export function Catalog({ sessionToken, onViewProperty, onAddToCart }: CatalogProps) {
  const [properties, setProperties] = useState<Property[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Toutes');
  const [selectedSaleType, setSelectedSaleType] = useState<string>('Tous');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');

  const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-efc46249`;

  useEffect(() => {
    fetchProperties();
    fetchCategories();
  }, []);

  const fetchProperties = async () => {
    try {
      const response = await fetch(`${API_BASE}/properties`);
      const data = await response.json();
      setProperties(data.properties || []);
    } catch (error) {
      console.error('Failed to fetch properties:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch(`${API_BASE}/categories`);
      const data = await response.json();
      setCategories(data.categories || []);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  };

  const filteredProperties = properties.filter((property) => {
    const matchesSearch = property.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         property.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         property.category.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'Toutes' || property.category === selectedCategory;
    const matchesSaleType = selectedSaleType === 'Tous' || 
                           (selectedSaleType === 'Vente' && property.saleType === 'vente') ||
                           (selectedSaleType === 'Location' && property.saleType === 'location');
    
    const min = minPrice ? parseFloat(minPrice) : 0;
    const max = maxPrice ? parseFloat(maxPrice) : Infinity;
    const matchesPrice = property.price >= min && property.price <= max;

    return matchesSearch && matchesCategory && matchesSaleType && matchesPrice;
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div>
      {/* Hero Section */}
      <div className="relative h-[500px] bg-black">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1706808849827-7366c098b317?w=1920"
            alt="Luxury House"
            className="w-full h-full object-cover opacity-50"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black" />
        </div>

        <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">
              Bienvenue chez Dynasty 8
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8">
              L'agence immobilière premium du serveur NewWave. Trouvez la propriété de vos rêves.
            </p>
            <Button 
              onClick={() => document.getElementById('properties')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-emerald-500 hover:bg-emerald-600 text-white font-semibold px-8 py-6 text-lg"
            >
              Commencer maintenant
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-[#1a1a1a] rounded-lg p-6 border border-gray-800">
              <div className="flex items-center gap-2 text-emerald-500 mb-4">
                <Filter className="w-5 h-5" />
                <h3 className="font-semibold">Filtres</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <div className="md:col-span-2">
                  <label className="text-xs text-gray-400 mb-1 block">Rechercher</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <Input
                      placeholder="Nom, catégorie..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 bg-black/50 border-gray-700 text-white placeholder:text-gray-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Type</label>
                  <Select value={selectedSaleType} onValueChange={setSelectedSaleType}>
                    <SelectTrigger className="bg-black/50 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Tous">Tous</SelectItem>
                      <SelectItem value="Vente">Vente</SelectItem>
                      <SelectItem value="Location">Location</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Catégorie</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="bg-black/50 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Toutes">Toutes</SelectItem>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs text-gray-400 mb-1 block">Prix min</label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={minPrice}
                      onChange={(e) => setMinPrice(e.target.value)}
                      className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 mb-1 block">Prix max</label>
                    <Input
                      type="number"
                      placeholder="∞"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(e.target.value)}
                      className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Properties Grid */}
      <div id="properties" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {loading ? (
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-white text-xl">Chargement des propriétés...</div>
          </div>
        ) : filteredProperties.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-gray-400 text-lg">Aucune propriété trouvée</p>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-6">
              <p className="text-gray-400">
                {filteredProperties.length} propriété{filteredProperties.length > 1 ? 's' : ''} trouvée{filteredProperties.length > 1 ? 's' : ''}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProperties.map((property) => (
                <Card key={property.id} className="bg-[#1a1a1a] border-gray-800 overflow-hidden hover:border-emerald-500/50 transition-all group">
                  <div className="relative h-48 overflow-hidden">
                    <ImageWithFallback
                      src={property.photos?.[0] || 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800'}
                      alt={property.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <Badge className="absolute top-3 right-3 bg-emerald-500 text-white border-0">
                      {property.saleType === 'vente' ? 'À vendre' : 'À louer'}
                    </Badge>
                  </div>
                  
                  <CardHeader>
                    <h3 className="text-lg font-bold text-white truncate">{property.name}</h3>
                    <div className="flex items-center gap-2 text-gray-400 text-sm">
                      <MapPin className="w-4 h-4" />
                      <p>{property.location || 'Los Santos'}</p>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2">
                      <p className="text-2xl font-bold text-emerald-500">{formatPrice(property.price)}</p>
                    </div>

                    <div className="flex gap-2 flex-wrap">
                      <Badge variant="outline" className="text-gray-400 border-gray-700">
                        {property.category}
                      </Badge>
                      {property.bedrooms && (
                        <Badge variant="outline" className="text-gray-400 border-gray-700">
                          {property.bedrooms} ch.
                        </Badge>
                      )}
                      {property.surface && (
                        <Badge variant="outline" className="text-gray-400 border-gray-700">
                          {property.surface} m²
                        </Badge>
                      )}
                    </div>

                    <p className="text-gray-400 text-sm line-clamp-2">
                      {property.description}
                    </p>
                  </CardContent>

                  <CardFooter className="gap-2">
                    <Button
                      variant="outline"
                      className="flex-1 border-gray-700 text-gray-300 hover:bg-white/5"
                      onClick={() => onViewProperty(property.id)}
                    >
                      Détails
                    </Button>
                    <Button
                      className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white"
                      onClick={() => onAddToCart(property)}
                    >
                      Au panier
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
