import { HelpCircle, ChevronDown } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Card, CardContent, CardHeader } from './ui/card';

export function FAQ() {
  const faqs = [
    {
      question: "Comment passer une commande ?",
      answer: "Pour passer une commande, parcourez notre catalogue, ajoutez les propriétés qui vous intéressent à votre panier, puis cliquez sur 'Passer commande'. Vous devez être connecté avec Discord et être membre du serveur Dynasty 8 pour finaliser votre commande."
    },
    {
      question: "Dois-je rejoindre le serveur Discord ?",
      answer: "Oui, vous devez obligatoirement rejoindre le serveur Discord Dynasty 8 pour pouvoir passer commande. Cela nous permet de créer un ticket privé pour discuter de votre achat et vous contacter en jeu."
    },
    {
      question: "Combien de temps faut-il pour recevoir ma propriété ?",
      answer: "Une fois votre commande passée, un de nos vendeurs vous contactera via Discord dans les 24 heures. Le délai de livraison dépend de la disponibilité de nos agents et de votre présence en jeu, mais nous faisons tout notre possible pour être rapides !"
    },
    {
      question: "Quelle est la différence entre vente et location ?",
      answer: "Les propriétés en 'Vente' sont achetées définitivement - vous en devenez propriétaire. Les propriétés en 'Location' nécessitent un paiement mensuel pour continuer à les utiliser. Le prix affiché pour une location est le loyer mensuel."
    },
    {
      question: "Puis-je annuler ma commande ?",
      answer: "Oui, tant que votre commande n'a pas été finalisée par un vendeur, vous pouvez la modifier ou l'annuler en contactant notre équipe via le ticket Discord qui sera créé automatiquement."
    },
    {
      question: "Comment fonctionnent les catégories spéciales (garage, entrepôt, etc.) ?",
      answer: "Chaque catégorie a des caractéristiques spécifiques : les garages indiquent le nombre de places de véhicules disponibles, les entrepôts affichent leur capacité de stockage en m³, les appartements/maisons montrent le nombre de chambres et la surface, etc."
    },
    {
      question: "Les prix sont-ils négociables ?",
      answer: "Les prix affichés sont fixes. Cependant, pour des achats en volume ou des demandes spéciales, vous pouvez discuter avec nos vendeurs via le ticket Discord."
    },
    {
      question: "Que se passe-t-il après avoir passé commande ?",
      answer: "Après votre commande : 1) Un message est envoyé dans notre canal Discord pour alerter nos vendeurs, 2) Un vendeur examinera votre demande, 3) Vous serez contacté sur Discord pour finaliser la transaction, 4) Une fois le paiement effectué en jeu, vous recevrez les clés de votre propriété !"
    },
    {
      question: "Puis-je visiter une propriété avant de l'acheter ?",
      answer: "Bien sûr ! Mentionnez dans les 'Notes / Demandes spéciales' lors de votre commande que vous souhaitez visiter la propriété. Un de nos agents se fera un plaisir de vous faire visiter."
    },
    {
      question: "Comment ajouter mes informations RP ?",
      answer: "Lors du passage de commande, vous devrez renseigner votre nom/prénom RP ainsi que votre numéro de téléphone en jeu. Ces informations permettent à nos vendeurs de vous contacter directement sur le serveur."
    },
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-500/10 rounded-full mb-4">
          <HelpCircle className="w-8 h-8 text-emerald-500" />
        </div>
        <h1 className="text-4xl font-bold text-white mb-4">Foire Aux Questions</h1>
        <p className="text-gray-400 text-lg">
          Tout ce que vous devez savoir sur Dynasty 8
        </p>
      </div>

      <Card className="bg-[#1a1a1a] border-gray-800">
        <CardHeader>
          <h2 className="text-xl font-semibold text-white">Questions fréquentes</h2>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border border-gray-800 rounded-lg px-4 bg-black/30"
              >
                <AccordionTrigger className="text-white hover:text-emerald-500 text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-400">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>

      <div className="mt-12 text-center">
        <Card className="bg-emerald-500/10 border-emerald-500/30">
          <CardContent className="py-8">
            <h3 className="text-xl font-bold text-white mb-2">Vous avez d'autres questions ?</h3>
            <p className="text-gray-400 mb-4">
              Notre équipe est disponible sur Discord pour vous aider
            </p>
            <p className="text-emerald-500 font-medium">
              Rejoignez le serveur Discord Dynasty 8
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
