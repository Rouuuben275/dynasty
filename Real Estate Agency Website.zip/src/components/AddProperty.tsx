import { useState, useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { Plus, X, Upload } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { projectId } from '../utils/supabase/info';

interface AddPropertyProps {
  sessionToken: string | null;
  onSuccess: () => void;
  onCancel: () => void;
}

export function AddProperty({ sessionToken, onSuccess, onCancel }: AddPropertyProps) {
  const [categories, setCategories] = useState<string[]>([]);
  const [newCategory, setNewCategory] = useState('');
  const [showAddCategory, setShowAddCategory] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    category: '',
    saleType: 'vente' as 'vente' | 'location',
    description: '',
    location: '',
    photos: [''],
    bedrooms: '',
    bathrooms: '',
    surface: '',
    garageSpaces: '',
    storage: '',
    features: [''],
  });

  const [loading, setLoading] = useState(false);

  const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-efc46249`;

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await fetch(`${API_BASE}/categories`);
      const data = await response.json();
      setCategories(data.categories || []);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  };

  const handleAddCategory = async () => {
    if (!newCategory.trim()) return;

    try {
      const response = await fetch(`${API_BASE}/categories`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionToken}`,
        },
        body: JSON.stringify({ category: newCategory }),
      });

      if (response.ok) {
        const data = await response.json();
        setCategories(data.categories);
        setFormData({ ...formData, category: newCategory });
        setNewCategory('');
        setShowAddCategory(false);
        toast.success('Catégorie ajoutée !');
      } else {
        const error = await response.json();
        toast.error(error.error || 'Erreur lors de l\'ajout de la catégorie');
      }
    } catch (error) {
      console.error('Add category error:', error);
      toast.error('Erreur de connexion');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Prepare data
      const propertyData: any = {
        name: formData.name,
        price: parseFloat(formData.price),
        category: formData.category,
        saleType: formData.saleType,
        description: formData.description,
        location: formData.location || 'Los Santos',
        photos: formData.photos.filter(p => p.trim() !== ''),
        features: formData.features.filter(f => f.trim() !== ''),
      };

      // Add category-specific fields
      if (formData.bedrooms) propertyData.bedrooms = parseInt(formData.bedrooms);
      if (formData.bathrooms) propertyData.bathrooms = parseInt(formData.bathrooms);
      if (formData.surface) propertyData.surface = parseFloat(formData.surface);
      if (formData.garageSpaces) propertyData.garageSpaces = parseInt(formData.garageSpaces);
      if (formData.storage) propertyData.storage = parseFloat(formData.storage);

      const response = await fetch(`${API_BASE}/properties`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionToken}`,
        },
        body: JSON.stringify(propertyData),
      });

      if (response.ok) {
        toast.success('Propriété ajoutée avec succès !');
        onSuccess();
      } else {
        const error = await response.json();
        toast.error(error.error || 'Erreur lors de l\'ajout de la propriété');
      }
    } catch (error) {
      console.error('Add property error:', error);
      toast.error('Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  const addPhotoField = () => {
    setFormData({ ...formData, photos: [...formData.photos, ''] });
  };

  const removePhotoField = (index: number) => {
    setFormData({ ...formData, photos: formData.photos.filter((_, i) => i !== index) });
  };

  const updatePhoto = (index: number, value: string) => {
    const newPhotos = [...formData.photos];
    newPhotos[index] = value;
    setFormData({ ...formData, photos: newPhotos });
  };

  const addFeatureField = () => {
    setFormData({ ...formData, features: [...formData.features, ''] });
  };

  const removeFeatureField = (index: number) => {
    setFormData({ ...formData, features: formData.features.filter((_, i) => i !== index) });
  };

  const updateFeature = (index: number, value: string) => {
    const newFeatures = [...formData.features];
    newFeatures[index] = value;
    setFormData({ ...formData, features: newFeatures });
  };

  const showGarageFields = formData.category === 'Garage';
  const showStorageFields = formData.category === 'Entrepôts';
  const showBedroomFields = ['Appartements', 'Appartements luxueux', 'Maisons modernes'].includes(formData.category);

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-[#1a1a1a] border-gray-800">
        <CardHeader>
          <h2 className="text-2xl font-bold text-white">Ajouter une propriété</h2>
          <p className="text-gray-400">Remplissez tous les champs pour ajouter une nouvelle propriété au catalogue</p>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-white">Nom de la propriété *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500"
                  placeholder="Villa de luxe..."
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="price" className="text-white">Prix (€) *</Label>
                <Input
                  id="price"
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500"
                  placeholder="500000"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category" className="text-white">Catégorie *</Label>
                <div className="flex gap-2">
                  <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })} required>
                    <SelectTrigger className="bg-black/50 border-gray-700 text-white flex-1">
                      <SelectValue placeholder="Sélectionnez une catégorie" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Dialog open={showAddCategory} onOpenChange={setShowAddCategory}>
                    <DialogTrigger asChild>
                      <Button type="button" variant="outline" className="border-gray-700 text-gray-300">
                        <Plus className="w-4 h-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-[#1a1a1a] border-gray-700">
                      <DialogHeader>
                        <DialogTitle className="text-white">Ajouter une catégorie</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <Input
                          value={newCategory}
                          onChange={(e) => setNewCategory(e.target.value)}
                          className="bg-black/50 border-gray-700 text-white"
                          placeholder="Nom de la catégorie"
                        />
                        <Button onClick={handleAddCategory} className="w-full bg-emerald-500 hover:bg-emerald-600">
                          Ajouter
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="saleType" className="text-white">Type *</Label>
                <Select value={formData.saleType} onValueChange={(value: any) => setFormData({ ...formData, saleType: value })}>
                  <SelectTrigger className="bg-black/50 border-gray-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vente">Vente</SelectItem>
                    <SelectItem value="location">Location</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="location" className="text-white">Localisation</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500"
                  placeholder="Los Santos, Vinewood Hills..."
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="description" className="text-white">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500 min-h-32"
                  placeholder="Description détaillée de la propriété..."
                  required
                />
              </div>
            </div>

            {/* Category-specific fields */}
            {formData.category && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {showBedroomFields && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="bedrooms" className="text-white">Nombre de chambres</Label>
                      <Input
                        id="bedrooms"
                        type="number"
                        value={formData.bedrooms}
                        onChange={(e) => setFormData({ ...formData, bedrooms: e.target.value })}
                        className="bg-black/50 border-gray-700 text-white"
                        placeholder="3"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bathrooms" className="text-white">Nombre de salles de bain</Label>
                      <Input
                        id="bathrooms"
                        type="number"
                        value={formData.bathrooms}
                        onChange={(e) => setFormData({ ...formData, bathrooms: e.target.value })}
                        className="bg-black/50 border-gray-700 text-white"
                        placeholder="2"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="surface" className="text-white">Surface (m²)</Label>
                      <Input
                        id="surface"
                        type="number"
                        value={formData.surface}
                        onChange={(e) => setFormData({ ...formData, surface: e.target.value })}
                        className="bg-black/50 border-gray-700 text-white"
                        placeholder="150"
                      />
                    </div>
                  </>
                )}

                {showGarageFields && (
                  <div className="space-y-2">
                    <Label htmlFor="garageSpaces" className="text-white">Nombre de places de garage</Label>
                    <Input
                      id="garageSpaces"
                      type="number"
                      value={formData.garageSpaces}
                      onChange={(e) => setFormData({ ...formData, garageSpaces: e.target.value })}
                      className="bg-black/50 border-gray-700 text-white"
                      placeholder="10"
                    />
                  </div>
                )}

                {showStorageFields && (
                  <div className="space-y-2">
                    <Label htmlFor="storage" className="text-white">Capacité de stockage (m³)</Label>
                    <Input
                      id="storage"
                      type="number"
                      value={formData.storage}
                      onChange={(e) => setFormData({ ...formData, storage: e.target.value })}
                      className="bg-black/50 border-gray-700 text-white"
                      placeholder="500"
                    />
                  </div>
                )}
              </div>
            )}

            {/* Photos */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-white">Photos (URLs)</Label>
                <Button type="button" onClick={addPhotoField} variant="outline" size="sm" className="border-gray-700 text-gray-300">
                  <Plus className="w-4 h-4 mr-1" />
                  Ajouter une photo
                </Button>
              </div>
              {formData.photos.map((photo, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={photo}
                    onChange={(e) => updatePhoto(index, e.target.value)}
                    className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500 flex-1"
                    placeholder="https://example.com/photo.jpg"
                  />
                  {formData.photos.length > 1 && (
                    <Button
                      type="button"
                      onClick={() => removePhotoField(index)}
                      variant="outline"
                      size="icon"
                      className="border-red-500/50 text-red-400 hover:bg-red-500/20"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            {/* Features */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-white">Caractéristiques</Label>
                <Button type="button" onClick={addFeatureField} variant="outline" size="sm" className="border-gray-700 text-gray-300">
                  <Plus className="w-4 h-4 mr-1" />
                  Ajouter
                </Button>
              </div>
              {formData.features.map((feature, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={feature}
                    onChange={(e) => updateFeature(index, e.target.value)}
                    className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500 flex-1"
                    placeholder="Piscine, Vue mer, Terrasse..."
                  />
                  {formData.features.length > 1 && (
                    <Button
                      type="button"
                      onClick={() => removeFeatureField(index)}
                      variant="outline"
                      size="icon"
                      className="border-red-500/50 text-red-400 hover:bg-red-500/20"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            {/* Actions */}
            <div className="flex gap-4 pt-4">
              <Button
                type="button"
                onClick={onCancel}
                variant="outline"
                className="flex-1 border-gray-700 text-gray-300 hover:bg-white/5"
              >
                Annuler
              </Button>
              <Button
                type="submit"
                disabled={loading}
                className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white"
              >
                {loading ? 'Ajout en cours...' : 'Ajouter la propriété'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}