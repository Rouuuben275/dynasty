# 🤖 Bot Discord pour Dynasty 8 (Optionnel)

Ce guide explique comment créer et héberger gratuitement un bot Discord qui crée automatiquement des salons privés pour chaque commande.

## 📋 Pourquoi un bot Discord ?

Le système actuel utilise des **webhooks** qui envoient simplement des notifications dans un canal. Un bot Discord permet de :

- ✅ Créer automatiquement un salon privé pour chaque commande
- ✅ Donner les permissions au client et aux vendeurs
- ✅ Archiver/supprimer le salon une fois la commande terminée
- ✅ Envoyer des messages personnalisés

## 🚀 Création du Bot Discord

### 1. Créer l'application Discord

1. Allez sur https://discord.com/developers/applications
2. Cliquez sur **"New Application"**
3. Donnez un nom : `Dynasty 8 Tickets`
4. Dans **Bot** :
   - Cliquez sur **"Add Bot"**
   - Activez : **Presence Intent**, **Server Members Intent**, **Message Content Intent**
   - Copiez le **Token** (gardez-le secret !)

### 2. Inviter le bot sur votre serveur

Allez dans **OAuth2** → **URL Generator** :
- Scopes : `bot`
- Permissions : `Administrator` (ou `Manage Channels` + `Manage Roles` + `Send Messages`)

Copiez l'URL générée et ouvrez-la pour inviter le bot.

## 💻 Code du Bot

Créez un nouveau dossier pour le bot :

```bash
mkdir dynasty8-bot
cd dynasty8-bot
npm init -y
npm install discord.js dotenv
```

Créez le fichier `bot.js` :

```javascript
const { Client, GatewayIntentBits, PermissionFlagsBits, ChannelType } = require('discord.js');
require('dotenv').config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

const GUILD_ID = '1459195760150319290';
const TICKET_CATEGORY_ID = 'VOTRE_CATEGORY_ID'; // Créez une catégorie "🎫 Tickets" et mettez son ID ici
const VENDOR_ROLE_ID = '1459196844432294066';
const TICKET_CHANNEL_ID = 'VOTRE_CHANNEL_ID'; // Le canal où les webhooks envoient les notifications

client.on('ready', () => {
  console.log(`✅ Bot connecté en tant que ${client.user.tag}`);
  console.log('🎫 Système de tickets Dynasty 8 actif !');
});

client.on('messageCreate', async (message) => {
  // Ignorer les messages du bot lui-même
  if (message.author.bot && message.author.id !== client.user.id) {
    // Vérifier si c'est un message de webhook contenant une commande
    if (message.webhookId && message.content.includes('NOUVELLE COMMANDE')) {
      try {
        await createTicket(message);
      } catch (error) {
        console.error('Erreur lors de la création du ticket:', error);
      }
    }
  }
});

async function createTicket(webhookMessage) {
  const guild = client.guilds.cache.get(GUILD_ID);
  if (!guild) return;

  // Extraire les informations de la commande
  const content = webhookMessage.content;
  const orderIdMatch = content.match(/Commande ID:\*\* (.+)/);
  const clientMatch = content.match(/Client Discord:\*\* (.+)/);
  
  if (!orderIdMatch || !clientMatch) return;

  const orderId = orderIdMatch[1].split('\n')[0].trim();
  const clientUsername = clientMatch[1].split('\n')[0].trim();

  // Trouver le membre (optionnel, mais utile pour les permissions)
  const members = await guild.members.fetch({ query: clientUsername, limit: 1 });
  const clientMember = members.first();

  // Créer le salon ticket
  const ticketChannel = await guild.channels.create({
    name: `ticket-${orderId.substring(0, 8)}`,
    type: ChannelType.GuildText,
    parent: TICKET_CATEGORY_ID,
    permissionOverwrites: [
      {
        id: guild.id, // @everyone
        deny: [PermissionFlagsBits.ViewChannel],
      },
      {
        id: VENDOR_ROLE_ID, // Vendeurs
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
      },
    ],
  });

  // Ajouter les permissions au client si trouvé
  if (clientMember) {
    await ticketChannel.permissionOverwrites.create(clientMember, {
      ViewChannel: true,
      SendMessages: true,
    });
  }

  // Envoyer le message de bienvenue dans le ticket
  await ticketChannel.send({
    content: `📋 **Nouvelle Commande Dynasty 8**\n\n${content}\n\n---\n\n${clientMember ? clientMember.toString() : `@${clientUsername}`} <@&${VENDOR_ROLE_ID}>\n\n✅ Un vendeur va vous contacter sous peu.\n🔒 Ce salon sera archivé une fois la transaction terminée.`,
  });

  console.log(`✅ Ticket créé: ${ticketChannel.name}`);

  // Réagir au message webhook pour confirmer
  await webhookMessage.react('✅');
}

// Commande pour fermer un ticket (optionnel)
client.on('messageCreate', async (message) => {
  if (message.content === '!close-ticket' && message.channel.name.startsWith('ticket-')) {
    const member = message.member;
    if (member.roles.cache.has(VENDOR_ROLE_ID)) {
      await message.channel.send('🔒 Ce ticket va être archivé dans 5 secondes...');
      
      setTimeout(async () => {
        await message.channel.delete();
      }, 5000);
    } else {
      await message.reply('❌ Seuls les vendeurs peuvent fermer les tickets.');
    }
  }
});

client.login(process.env.DISCORD_BOT_TOKEN);
```

Créez le fichier `.env` :

```env
DISCORD_BOT_TOKEN=votre_token_bot_ici
```

Créez le fichier `.gitignore` :

```
node_modules/
.env
```

## 🌐 Hébergement Gratuit

### Option 1 : Railway.app (Recommandé)

**Railway** offre 500h gratuites par mois (suffisant pour un bot 24/7).

1. Allez sur https://railway.app
2. Connectez-vous avec GitHub
3. Cliquez sur **"New Project"** → **"Deploy from GitHub repo"**
4. Sélectionnez votre repository (créez-en un avec le code du bot)
5. Ajoutez la variable d'environnement :
   - Nom: `DISCORD_BOT_TOKEN`
   - Valeur: Votre token bot
6. Railway détectera automatiquement Node.js et lancera le bot !

**Commande de démarrage** : `node bot.js`

### Option 2 : Render.com

1. Allez sur https://render.com
2. Créez un compte gratuit
3. Cliquez sur **"New +"** → **"Background Worker"**
4. Connectez votre repository GitHub
5. Configuration :
   - **Build Command** : `npm install`
   - **Start Command** : `node bot.js`
6. Ajoutez la variable d'environnement `DISCORD_BOT_TOKEN`
7. Cliquez sur **"Create Background Worker"**

### Option 3 : Replit

1. Allez sur https://replit.com
2. Créez un nouveau Repl Node.js
3. Copiez le code du bot
4. Dans **Secrets** (🔒), ajoutez `DISCORD_BOT_TOKEN`
5. Installez les dépendances : `npm install discord.js dotenv`
6. Cliquez sur **Run**

**Important pour Replit** : Ajoutez UptimeRobot pour garder le bot actif 24/7 :
- Ajoutez un serveur web simple dans le bot
- Utilisez https://uptimerobot.com pour ping le bot toutes les 5 min

### Option 4 : fly.io

1. Installez flyctl : https://fly.io/docs/hands-on/install-flyctl/
2. Connectez-vous : `flyctl auth login`
3. Lancez : `flyctl launch`
4. Configurez les secrets : `flyctl secrets set DISCORD_BOT_TOKEN=votre_token`
5. Déployez : `flyctl deploy`

## 📝 Configuration du Bot

### Obtenir les IDs nécessaires

**Category ID** :
1. Sur Discord, activez le **Mode Développeur** : Paramètres → Avancés → Mode développeur
2. Créez une catégorie "🎫 Tickets Dynasty 8"
3. Clic droit → Copier l'identifiant

**Channel ID** :
1. Trouvez le canal où le webhook envoie les notifications
2. Clic droit → Copier l'identifiant

Remplacez ces valeurs dans `bot.js`.

## 🔧 Test du Bot

1. Passez une commande sur le site
2. Le webhook enverra un message dans Discord
3. Le bot détectera le message et créera automatiquement un salon ticket
4. Le client et les vendeurs auront accès au salon

Pour fermer un ticket, tapez `!close-ticket` dans le salon (seulement les vendeurs).

## 🎨 Améliorations Possibles

### Boutons interactifs

```javascript
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const row = new ActionRowBuilder()
  .addComponents(
    new ButtonBuilder()
      .setCustomId('mark_completed')
      .setLabel('✅ Marquer comme terminé')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('close_ticket')
      .setLabel('🔒 Fermer le ticket')
      .setStyle(ButtonStyle.Danger),
  );

await ticketChannel.send({
  content: 'Actions disponibles :',
  components: [row],
});
```

### Logs des transactions

Créez un salon `#logs-dynasty8` et envoyez-y un récapitulatif de chaque transaction.

### Système de notation

Après la transaction, demandez au client de noter le service.

## ❓ FAQ Bot Discord

**Q : Le bot est obligatoire ?**
R : Non ! Le système de webhooks actuel fonctionne déjà. Le bot ajoute juste des salons privés automatiques.

**Q : Le bot coûte de l'argent ?**
R : Non, avec Railway, Render ou Replit, vous pouvez héberger gratuitement un petit bot Discord 24/7.

**Q : Je n'ai pas de Category ID ?**
R : Créez une catégorie dans Discord, activez le mode développeur, puis clic droit → Copier l'identifiant.

**Q : Le bot ne se lance pas ?**
R : Vérifiez que :
- Le token est correct
- Les intents sont activés sur le portail Discord
- Node.js est installé (v16+)

## 📞 Support

Si vous avez des problèmes avec le bot, vérifiez :
1. Les logs sur votre plateforme d'hébergement
2. Que le bot est bien en ligne sur Discord (point vert)
3. Que les IDs (guild, category, role) sont corrects

---

✅ Une fois configuré, le système sera entièrement automatisé !
