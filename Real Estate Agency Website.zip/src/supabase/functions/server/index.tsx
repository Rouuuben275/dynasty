import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors());
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

const DISCORD_CONFIG = {
  clientId: '1459197358347911262',
  guildId: '1459195760150319290',
  adminRoleId: '1459196167991595008',
  ticketViewRoleId: '1459196844432294066',
  webhookUrl: 'https://discord.com/api/webhooks/1459196564206518437/oX0lLde_yDUsZOVPt9UpZALsi2rdcKxJWI9MgB4IENLsbgOEg2conl3Y5eTnrDhfOpMY',
};

// Discord OAuth flow
app.get('/make-server-efc46249/auth/discord', (c) => {
  const redirectUri = `${Deno.env.get('SUPABASE_URL')}/functions/v1/make-server-efc46249/auth/callback`;
  const discordAuthUrl = `https://discord.com/api/oauth2/authorize?client_id=${DISCORD_CONFIG.clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=identify+guilds.join+guilds.members.read`;
  
  return c.redirect(discordAuthUrl);
});

app.get('/make-server-efc46249/auth/callback', async (c) => {
  try {
    const code = c.req.query('code');
    if (!code) {
      return c.json({ error: 'No code provided' }, 400);
    }

    const redirectUri = `${Deno.env.get('SUPABASE_URL')}/functions/v1/make-server-efc46249/auth/callback`;
    
    // Exchange code for access token
    const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        client_id: DISCORD_CONFIG.clientId,
        client_secret: Deno.env.get('DISCORD_CLIENT_SECRET') ?? '',
        grant_type: 'authorization_code',
        code,
        redirect_uri: redirectUri,
      }),
    });

    const tokenData = await tokenResponse.json();
    
    if (!tokenResponse.ok) {
      console.log('Discord token error:', tokenData);
      return c.json({ error: 'Failed to get Discord token', details: tokenData }, 400);
    }

    // Get user info
    const userResponse = await fetch('https://discord.com/api/users/@me', {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
      },
    });

    const userData = await userResponse.json();

    // Check if user is in the guild and get their roles
    const guildMemberResponse = await fetch(
      `https://discord.com/api/users/@me/guilds/${DISCORD_CONFIG.guildId}/member`,
      {
        headers: {
          Authorization: `Bearer ${tokenData.access_token}`,
        },
      }
    );

    let userRoles: string[] = [];
    let isInGuild = false;

    if (guildMemberResponse.ok) {
      const memberData = await guildMemberResponse.json();
      userRoles = memberData.roles || [];
      isInGuild = true;
    }

    // Store user session
    const sessionToken = crypto.randomUUID();
    await kv.set(`session:${sessionToken}`, {
      userId: userData.id,
      username: userData.username,
      discriminator: userData.discriminator,
      avatar: userData.avatar,
      roles: userRoles,
      isInGuild,
      accessToken: tokenData.access_token,
      createdAt: Date.now(),
    });

    // Redirect to frontend with session token
    const frontendUrl = Deno.env.get('SUPABASE_URL')?.replace('.supabase.co', '.netlify.app') || 'http://localhost:5173';
    return c.redirect(`${frontendUrl}?session=${sessionToken}`);
  } catch (error) {
    console.log('Auth callback error:', error);
    return c.json({ error: 'Authentication failed', details: error.message }, 500);
  }
});

// Get current user
app.get('/make-server-efc46249/auth/me', async (c) => {
  try {
    const sessionToken = c.req.header('Authorization')?.replace('Bearer ', '');
    if (!sessionToken) {
      return c.json({ error: 'No session token' }, 401);
    }

    const session = await kv.get(`session:${sessionToken}`);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }

    const hasAdminRole = session.roles?.includes(DISCORD_CONFIG.adminRoleId);
    const hasTicketRole = session.roles?.includes(DISCORD_CONFIG.ticketViewRoleId);

    return c.json({
      user: {
        id: session.userId,
        username: session.username,
        discriminator: session.discriminator,
        avatar: session.avatar,
        isInGuild: session.isInGuild,
      },
      permissions: {
        canManageProperties: hasAdminRole,
        canViewTickets: hasTicketRole || hasAdminRole,
      },
    });
  } catch (error) {
    console.log('Get user error:', error);
    return c.json({ error: 'Failed to get user', details: error.message }, 500);
  }
});

// Logout
app.post('/make-server-efc46249/auth/logout', async (c) => {
  try {
    const sessionToken = c.req.header('Authorization')?.replace('Bearer ', '');
    if (sessionToken) {
      await kv.del(`session:${sessionToken}`);
    }
    return c.json({ success: true });
  } catch (error) {
    console.log('Logout error:', error);
    return c.json({ error: 'Logout failed', details: error.message }, 500);
  }
});

// Get all properties
app.get('/make-server-efc46249/properties', async (c) => {
  try {
    const properties = await kv.getByPrefix('property:');
    return c.json({ properties: properties.sort((a, b) => b.createdAt - a.createdAt) });
  } catch (error) {
    console.log('Get properties error:', error);
    return c.json({ error: 'Failed to get properties', details: error.message }, 500);
  }
});

// Get single property
app.get('/make-server-efc46249/properties/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const property = await kv.get(`property:${id}`);
    
    if (!property) {
      return c.json({ error: 'Property not found' }, 404);
    }

    return c.json({ property });
  } catch (error) {
    console.log('Get property error:', error);
    return c.json({ error: 'Failed to get property', details: error.message }, 500);
  }
});

// Create property (requires admin role)
app.post('/make-server-efc46249/properties', async (c) => {
  try {
    const sessionToken = c.req.header('Authorization')?.replace('Bearer ', '');
    if (!sessionToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const session = await kv.get(`session:${sessionToken}`);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }

    const hasAdminRole = session.roles?.includes(DISCORD_CONFIG.adminRoleId);
    if (!hasAdminRole) {
      return c.json({ error: 'Permission denied - Admin role required' }, 403);
    }

    const body = await c.req.json();
    const propertyId = crypto.randomUUID();

    const property = {
      id: propertyId,
      ...body,
      createdAt: Date.now(),
      createdBy: session.userId,
    };

    await kv.set(`property:${propertyId}`, property);

    return c.json({ property }, 201);
  } catch (error) {
    console.log('Create property error:', error);
    return c.json({ error: 'Failed to create property', details: error.message }, 500);
  }
});

// Update property (requires admin role)
app.put('/make-server-efc46249/properties/:id', async (c) => {
  try {
    const sessionToken = c.req.header('Authorization')?.replace('Bearer ', '');
    if (!sessionToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const session = await kv.get(`session:${sessionToken}`);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }

    const hasAdminRole = session.roles?.includes(DISCORD_CONFIG.adminRoleId);
    if (!hasAdminRole) {
      return c.json({ error: 'Permission denied - Admin role required' }, 403);
    }

    const id = c.req.param('id');
    const existingProperty = await kv.get(`property:${id}`);

    if (!existingProperty) {
      return c.json({ error: 'Property not found' }, 404);
    }

    const body = await c.req.json();
    const updatedProperty = {
      ...existingProperty,
      ...body,
      id,
      updatedAt: Date.now(),
    };

    await kv.set(`property:${id}`, updatedProperty);

    return c.json({ property: updatedProperty });
  } catch (error) {
    console.log('Update property error:', error);
    return c.json({ error: 'Failed to update property', details: error.message }, 500);
  }
});

// Delete property (requires admin role)
app.delete('/make-server-efc46249/properties/:id', async (c) => {
  try {
    const sessionToken = c.req.header('Authorization')?.replace('Bearer ', '');
    if (!sessionToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const session = await kv.get(`session:${sessionToken}`);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }

    const hasAdminRole = session.roles?.includes(DISCORD_CONFIG.adminRoleId);
    if (!hasAdminRole) {
      return c.json({ error: 'Permission denied - Admin role required' }, 403);
    }

    const id = c.req.param('id');
    await kv.del(`property:${id}`);

    return c.json({ success: true });
  } catch (error) {
    console.log('Delete property error:', error);
    return c.json({ error: 'Failed to delete property', details: error.message }, 500);
  }
});

// Get all categories
app.get('/make-server-efc46249/categories', async (c) => {
  try {
    const categoriesData = await kv.get('categories');
    const defaultCategories = [
      'Appartements',
      'Appartements luxueux',
      'Maisons modernes',
      'Bureaux',
      'Entrepôts',
      'Club de biker',
      'Garage',
    ];

    return c.json({ categories: categoriesData?.list || defaultCategories });
  } catch (error) {
    console.log('Get categories error:', error);
    return c.json({ error: 'Failed to get categories', details: error.message }, 500);
  }
});

// Add category (requires admin role)
app.post('/make-server-efc46249/categories', async (c) => {
  try {
    const sessionToken = c.req.header('Authorization')?.replace('Bearer ', '');
    if (!sessionToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const session = await kv.get(`session:${sessionToken}`);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }

    const hasAdminRole = session.roles?.includes(DISCORD_CONFIG.adminRoleId);
    if (!hasAdminRole) {
      return c.json({ error: 'Permission denied - Admin role required' }, 403);
    }

    const { category } = await c.req.json();
    const categoriesData = await kv.get('categories');
    const currentCategories = categoriesData?.list || [
      'Appartements',
      'Appartements luxueux',
      'Maisons modernes',
      'Bureaux',
      'Entrepôts',
      'Club de biker',
      'Garage',
    ];

    if (!currentCategories.includes(category)) {
      currentCategories.push(category);
      await kv.set('categories', { list: currentCategories });
    }

    return c.json({ categories: currentCategories });
  } catch (error) {
    console.log('Add category error:', error);
    return c.json({ error: 'Failed to add category', details: error.message }, 500);
  }
});

// Create order and Discord ticket
app.post('/make-server-efc46249/orders', async (c) => {
  try {
    const sessionToken = c.req.header('Authorization')?.replace('Bearer ', '');
    if (!sessionToken) {
      return c.json({ error: 'Unauthorized - Please login' }, 401);
    }

    const session = await kv.get(`session:${sessionToken}`);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }

    if (!session.isInGuild) {
      return c.json({ 
        error: 'Vous devez rejoindre le serveur Discord Dynasty 8 pour passer commande',
        joinUrl: 'https://discord.gg/votre-invitation'
      }, 403);
    }

    const body = await c.req.json();
    const orderId = crypto.randomUUID();

    const order = {
      id: orderId,
      userId: session.userId,
      username: session.username,
      items: body.items,
      rpName: body.rpName,
      phoneNumber: body.phoneNumber,
      notes: body.notes,
      status: 'pending',
      createdAt: Date.now(),
    };

    await kv.set(`order:${orderId}`, order);

    // Create Discord webhook message to notify about new order
    const propertyNames = body.items.map((item: any) => item.name).join(', ');
    
    const webhookPayload = {
      content: `📋 **NOUVELLE COMMANDE** - Dynasty 8\n\n` +
        `**Commande ID:** ${orderId}\n` +
        `**Client Discord:** ${session.username}\n` +
        `**Nom RP:** ${body.rpName}\n` +
        `**Téléphone RP:** ${body.phoneNumber}\n` +
        `**Propriétés:** ${propertyNames}\n` +
        `**Notes:** ${body.notes || 'Aucune'}\n\n` +
        `<@&${DISCORD_CONFIG.ticketViewRoleId}> - Une nouvelle commande nécessite votre attention !`,
    };

    try {
      await fetch(DISCORD_CONFIG.webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(webhookPayload),
      });
    } catch (webhookError) {
      console.log('Discord webhook error:', webhookError);
      // Continue even if webhook fails
    }

    return c.json({ order }, 201);
  } catch (error) {
    console.log('Create order error:', error);
    return c.json({ error: 'Failed to create order', details: error.message }, 500);
  }
});

// Get all orders (requires ticket view role)
app.get('/make-server-efc46249/orders', async (c) => {
  try {
    const sessionToken = c.req.header('Authorization')?.replace('Bearer ', '');
    if (!sessionToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const session = await kv.get(`session:${sessionToken}`);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }

    const hasTicketRole = session.roles?.includes(DISCORD_CONFIG.ticketViewRoleId);
    const hasAdminRole = session.roles?.includes(DISCORD_CONFIG.adminRoleId);

    if (!hasTicketRole && !hasAdminRole) {
      return c.json({ error: 'Permission denied - Ticket view role required' }, 403);
    }

    const orders = await kv.getByPrefix('order:');
    return c.json({ orders: orders.sort((a, b) => b.createdAt - a.createdAt) });
  } catch (error) {
    console.log('Get orders error:', error);
    return c.json({ error: 'Failed to get orders', details: error.message }, 500);
  }
});

// Update order status (requires ticket view role)
app.put('/make-server-efc46249/orders/:id', async (c) => {
  try {
    const sessionToken = c.req.header('Authorization')?.replace('Bearer ', '');
    if (!sessionToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const session = await kv.get(`session:${sessionToken}`);
    if (!session) {
      return c.json({ error: 'Invalid session' }, 401);
    }

    const hasTicketRole = session.roles?.includes(DISCORD_CONFIG.ticketViewRoleId);
    const hasAdminRole = session.roles?.includes(DISCORD_CONFIG.adminRoleId);

    if (!hasTicketRole && !hasAdminRole) {
      return c.json({ error: 'Permission denied - Ticket view role required' }, 403);
    }

    const id = c.req.param('id');
    const existingOrder = await kv.get(`order:${id}`);

    if (!existingOrder) {
      return c.json({ error: 'Order not found' }, 404);
    }

    const { status } = await c.req.json();
    const updatedOrder = {
      ...existingOrder,
      status,
      updatedAt: Date.now(),
      updatedBy: session.userId,
    };

    await kv.set(`order:${id}`, updatedOrder);

    return c.json({ order: updatedOrder });
  } catch (error) {
    console.log('Update order error:', error);
    return c.json({ error: 'Failed to update order', details: error.message }, 500);
  }
});

Deno.serve(app.fetch);
