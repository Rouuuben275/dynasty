# Dynasty 8 - Agence Immobilière NewWave

Site web pour l'agence immobilière Dynasty 8 sur le serveur FiveM NewWave.

## 🚀 Fonctionnalités

- ✅ Authentification Discord OAuth avec système de permissions
- ✅ Catalogue de propriétés avec filtres avancés
- ✅ Système de panier et commandes
- ✅ Panneau d'administration pour gérer les propriétés
- ✅ Notifications Discord via webhook
- ✅ Catégories dynamiques personnalisables
- ✅ Section FAQ

## 📋 Prérequis

- Un compte Supabase (gratuit)
- Une application Discord
- Un serveur Discord
- Node.js 18+ (pour le développement local)

## 🔧 Configuration

### 1. Discord Application

1. Allez sur https://discord.com/developers/applications
2. Créez une nouvelle application ou sélectionnez votre application existante (Client ID: `1459197358347911262`)
3. Dans **OAuth2** :
   - Copiez le **Client Secret** (gardez-le secret !)
   - Ajoutez ces **Redirect URLs** :
     ```
     https://[VOTRE-PROJECT-ID].supabase.co/functions/v1/make-server-efc46249/auth/callback
     https://[VOTRE-SITE].netlify.app
     ```

### 2. Configuration Supabase

1. Créez un projet sur https://supabase.com
2. Allez dans **Settings** → **Edge Functions** → **Secrets**
3. Ajoutez le secret :
   - Nom: `DISCORD_CLIENT_SECRET`
   - Valeur: Votre Client Secret Discord

### 3. Informations Discord

Le site est configuré avec :
- **Guild ID** : `1459195760150319290`
- **Role Admin** (peut gérer les propriétés) : `1459196167991595008`
- **Role Tickets** (peut voir les commandes) : `1459196844432294066`
- **Webhook URL** : Configuré dans le serveur backend

## 🌐 Déploiement sur Netlify

### Option 1 : Via GitHub

1. Poussez votre code sur GitHub
2. Connectez-vous sur https://netlify.com
3. Cliquez sur **"Add new site"** → **"Import an existing project"**
4. Sélectionnez votre repository GitHub
5. Configuration build :
   - **Build command** : `npm run build`
   - **Publish directory** : `dist`
6. Cliquez sur **"Deploy"**

### Option 2 : Via Netlify CLI

```bash
# Installer Netlify CLI
npm install -g netlify-cli

# Se connecter
netlify login

# Initialiser le projet
netlify init

# Déployer
netlify deploy --prod
```

## 🤖 Bot Discord (Optionnel)

Le système actuel utilise des webhooks Discord pour notifier les vendeurs. Si vous souhaitez créer des salons privés automatiques pour chaque commande, vous aurez besoin d'un bot Discord.

Consultez le fichier [BOT_DISCORD_README.md](./BOT_DISCORD_README.md) pour les instructions détaillées.

## ✅ Vérification du fonctionnement

### Test de l'authentification Discord

1. Cliquez sur "Connexion Discord"
2. Autorisez l'application
3. Vous devriez être redirigé vers le site avec votre profil Discord visible

**Problèmes courants :**
- ❌ **"No code provided"** : Vérifiez que les Redirect URLs sont corrects
- ❌ **"Invalid session"** : Le DISCORD_CLIENT_SECRET n'est pas configuré dans Supabase
- ❌ **Erreur de connexion** : Vérifiez que votre Project ID Supabase est correct dans `/utils/supabase/info.tsx`

### Test de création de propriétés

1. Connectez-vous avec un compte Discord ayant le rôle `1459196167991595008`
2. Cliquez sur "Ajouter" dans le menu
3. Remplissez le formulaire
4. La propriété devrait apparaître dans le catalogue

**Problèmes courants :**
- ❌ **"Permission denied"** : Votre compte Discord n'a pas le bon rôle
- ❌ **Formulaire ne s'affiche pas** : Vous n'êtes pas connecté ou n'avez pas les permissions

### Test des catégories

1. Allez dans "Ajouter une propriété"
2. Cliquez sur le bouton **+** à côté du sélecteur de catégorie
3. Ajoutez une nouvelle catégorie
4. Elle apparaîtra dans les filtres et le formulaire

### Test des commandes

1. Ajoutez une propriété au panier
2. Allez dans le panier
3. Remplissez vos informations RP
4. Passez commande
5. Un message devrait apparaître dans votre canal Discord (via webhook)

**Important :** L'utilisateur doit être membre du serveur Discord `1459195760150319290`

## 🎨 Personnalisation

### Modifier les couleurs

Le site utilise Tailwind CSS v4. Les couleurs principales sont :
- Vert émeraude : `emerald-500` (#10b981)
- Fond noir : `#0a0a0a`
- Gris foncé : `#1a1a1a`

### Ajouter des sections

Ajoutez de nouvelles pages dans `/components/` et importez-les dans `App.tsx`.

### Modifier la FAQ

Éditez le fichier `/components/FAQ.tsx` pour ajouter/modifier les questions.

## 📝 Structure du projet

```
/
├── App.tsx                 # Composant principal
├── components/
│   ├── Catalog.tsx         # Page catalogue avec hero
│   ├── PropertyDetails.tsx # Détails d'une propriété
│   ├── AddProperty.tsx     # Formulaire ajout propriété
│   ├── Cart.tsx            # Panier
│   ├── Orders.tsx          # Gestion des commandes
│   ├── FAQ.tsx             # Page FAQ
│   └── ui/                 # Composants UI
├── supabase/
│   └── functions/
│       └── server/
│           └── index.tsx   # Backend API
└── utils/
    └── supabase/
        └── info.tsx        # Config Supabase
```

## 🐛 Debugging

### Activer les logs

Le serveur backend log automatiquement dans la console Supabase :
1. Allez dans **Edge Functions** → **server** → **Logs**
2. Vous verrez toutes les requêtes et erreurs

### Erreurs courantes

**"Failed to fetch properties"**
- Vérifiez que le serveur backend est déployé sur Supabase
- Vérifiez l'URL de l'API dans le code

**"Discord authentication failed"**
- Vérifiez le DISCORD_CLIENT_SECRET
- Vérifiez les Redirect URLs
- Assurez-vous que l'application Discord a les bons scopes

## 📞 Support

Pour toute question, contactez l'équipe Dynasty 8 sur Discord.

## 📄 Licence

Projet privé - Dynasty 8 © 2026
