import { useState, useEffect } from 'react';
import { Toaster, toast } from 'sonner@2.0.3';
import { Home, Building2, ShoppingCart, User, LogOut, Plus, Package, HelpCircle } from 'lucide-react';
import { Catalog } from './components/Catalog';
import { PropertyDetails } from './components/PropertyDetails';
import { AddProperty } from './components/AddProperty';
import { Cart } from './components/Cart';
import { Orders } from './components/Orders';
import { FAQ } from './components/FAQ';
import { Button } from './components/ui/button';
import { projectId, publicAnonKey } from './utils/supabase/info';

interface User {
  id: string;
  username: string;
  discriminator: string;
  avatar: string;
  isInGuild: boolean;
}

interface Permissions {
  canManageProperties: boolean;
  canViewTickets: boolean;
}

type Page = 'catalog' | 'property' | 'add-property' | 'cart' | 'orders' | 'faq';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [permissions, setPermissions] = useState<Permissions>({ canManageProperties: false, canViewTickets: false });
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<Page>('catalog');
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [cart, setCart] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-efc46249`;

  useEffect(() => {
    // Check for session token in URL or localStorage
    const params = new URLSearchParams(window.location.search);
    const sessionFromUrl = params.get('session');
    
    if (sessionFromUrl) {
      localStorage.setItem('dynasty8_session', sessionFromUrl);
      setSessionToken(sessionFromUrl);
      window.history.replaceState({}, '', '/');
    } else {
      const sessionFromStorage = localStorage.getItem('dynasty8_session');
      if (sessionFromStorage) {
        setSessionToken(sessionFromStorage);
      }
    }

    setLoading(false);
  }, []);

  useEffect(() => {
    if (sessionToken) {
      fetchUser();
    }
  }, [sessionToken]);

  const fetchUser = async () => {
    try {
      const response = await fetch(`${API_BASE}/auth/me`, {
        headers: {
          'Authorization': `Bearer ${sessionToken}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
        setPermissions(data.permissions);
      } else {
        // Invalid session
        localStorage.removeItem('dynasty8_session');
        setSessionToken(null);
      }
    } catch (error) {
      console.error('Failed to fetch user:', error);
    }
  };

  const handleLogin = () => {
    window.location.href = `${API_BASE}/auth/discord`;
  };

  const handleLogout = async () => {
    try {
      await fetch(`${API_BASE}/auth/logout`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${sessionToken}`,
        },
      });
    } catch (error) {
      console.error('Logout error:', error);
    }

    localStorage.removeItem('dynasty8_session');
    setSessionToken(null);
    setUser(null);
    setPermissions({ canManageProperties: false, canViewTickets: false });
    setCurrentPage('catalog');
    toast.success('Déconnexion réussie');
  };

  const handleViewProperty = (propertyId: string) => {
    setSelectedPropertyId(propertyId);
    setCurrentPage('property');
  };

  const handleAddToCart = (property: any) => {
    setCart([...cart, property]);
    toast.success('Ajouté au panier !');
  };

  const handleRemoveFromCart = (index: number) => {
    const newCart = cart.filter((_, i) => i !== index);
    setCart(newCart);
    toast.success('Retiré du panier');
  };

  const handleCheckout = () => {
    setCart([]);
    setCurrentPage('catalog');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-2xl">Chargement...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      <Toaster position="top-right" richColors />
      
      {/* Header */}
      <header className="bg-black/80 backdrop-blur-sm border-b border-gray-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentPage('catalog')}>
              <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
                <Home className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white tracking-tight">Dynasty 8</h1>
                <p className="text-xs text-gray-400">NewWave Server</p>
              </div>
            </div>

            <nav className="hidden md:flex items-center gap-6">
              <Button
                variant="ghost"
                className="text-gray-300 hover:text-white hover:bg-white/5"
                onClick={() => setCurrentPage('catalog')}
              >
                Catalogue
              </Button>

              <Button
                variant="ghost"
                className="text-gray-300 hover:text-white hover:bg-white/5"
                onClick={() => setCurrentPage('faq')}
              >
                FAQ
              </Button>

              {permissions.canManageProperties && (
                <Button
                  variant="ghost"
                  className="text-gray-300 hover:text-white hover:bg-white/5"
                  onClick={() => setCurrentPage('add-property')}
                >
                  Ajouter
                </Button>
              )}

              {permissions.canViewTickets && (
                <Button
                  variant="ghost"
                  className="text-gray-300 hover:text-white hover:bg-white/5"
                  onClick={() => setCurrentPage('orders')}
                >
                  Commandes
                </Button>
              )}

              <Button
                variant="ghost"
                className="text-gray-300 hover:text-white hover:bg-white/5 relative"
                onClick={() => setCurrentPage('cart')}
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                Panier
                {cart.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-emerald-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {cart.length}
                  </span>
                )}
              </Button>
            </nav>

            <div className="flex items-center gap-4">
              {user ? (
                <div className="flex items-center gap-3">
                  {user.avatar ? (
                    <img
                      src={`https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`}
                      alt={user.username}
                      className="w-8 h-8 rounded-full"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white font-bold text-sm">
                      {user.username[0].toUpperCase()}
                    </div>
                  )}
                  <div className="hidden lg:block">
                    <p className="text-white text-sm font-medium">{user.username}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleLogout}
                    className="text-gray-400 hover:text-red-400 hover:bg-white/5"
                  >
                    <LogOut className="w-4 h-4" />
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={handleLogin}
                  className="bg-[#5865F2] hover:bg-[#4752C4] text-white font-medium"
                >
                  Connexion Discord
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden border-t border-gray-800 px-4 py-3 flex gap-2 overflow-x-auto">
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-300 hover:text-white hover:bg-white/5 whitespace-nowrap"
            onClick={() => setCurrentPage('catalog')}
          >
            Catalogue
          </Button>

          <Button
            variant="ghost"
            size="sm"
            className="text-gray-300 hover:text-white hover:bg-white/5 whitespace-nowrap"
            onClick={() => setCurrentPage('faq')}
          >
            FAQ
          </Button>

          {permissions.canManageProperties && (
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-300 hover:text-white hover:bg-white/5 whitespace-nowrap"
              onClick={() => setCurrentPage('add-property')}
            >
              Ajouter
            </Button>
          )}

          {permissions.canViewTickets && (
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-300 hover:text-white hover:bg-white/5 whitespace-nowrap"
              onClick={() => setCurrentPage('orders')}
            >
              Commandes
            </Button>
          )}

          <Button
            variant="ghost"
            size="sm"
            className="text-gray-300 hover:text-white hover:bg-white/5 relative whitespace-nowrap"
            onClick={() => setCurrentPage('cart')}
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Panier
            {cart.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-emerald-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {cart.length}
              </span>
            )}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main>
        {currentPage === 'catalog' && (
          <Catalog
            sessionToken={sessionToken}
            onViewProperty={handleViewProperty}
            onAddToCart={handleAddToCart}
          />
        )}

        {currentPage === 'property' && selectedPropertyId && (
          <PropertyDetails
            propertyId={selectedPropertyId}
            sessionToken={sessionToken}
            onBack={() => setCurrentPage('catalog')}
            onAddToCart={handleAddToCart}
          />
        )}

        {currentPage === 'add-property' && permissions.canManageProperties && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <AddProperty
              sessionToken={sessionToken}
              onSuccess={() => {
                setCurrentPage('catalog');
                toast.success('Propriété ajoutée avec succès !');
              }}
              onCancel={() => setCurrentPage('catalog')}
            />
          </div>
        )}

        {currentPage === 'cart' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <Cart
              cart={cart}
              sessionToken={sessionToken}
              user={user}
              onRemoveFromCart={handleRemoveFromCart}
              onCheckout={handleCheckout}
            />
          </div>
        )}

        {currentPage === 'orders' && permissions.canViewTickets && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <Orders sessionToken={sessionToken} />
          </div>
        )}

        {currentPage === 'faq' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <FAQ />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-black/80 border-t border-gray-800 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-400">
            <p className="text-sm">© 2026 Dynasty 8 - NewWave Real Estate Agency</p>
            <p className="text-xs mt-2">Votre partenaire immobilier de confiance sur FiveM</p>
          </div>
        </div>
      </footer>
    </div>
  );
}